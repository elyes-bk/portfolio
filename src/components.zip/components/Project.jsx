'use client'
import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';


const Project = () => {
    const projects = [
        {
            title: "Projet 1",
            description: "Description du projet 1",
            imageUrl: "/assets/pc.jpg"
        },
        {
            title: "Projet 2",
            description: "Description du projet 2",
            imageUrl: "/assets/pc.jpg"
        },
        {
            title: "Projet 3",
            description: "Description du projet 3",
            imageUrl: "/assets/pc.jpg"
        },
        {
            title: "Projet 4",
            description: "Description du projet 4",
            imageUrl: "/assets/pc.jpg"
        }
    ];

    return (
        <section className="flex flex-col items-center pt-16 bg-[#1E3A5F]">
            <h2 className="text-3xl font-bold text-center text-[#FAF8F5] mt-4 mb-10">Mes Projets</h2>
            <div className=" relative px-16">
                <Carousel
                    showArrows={true}   
                    showStatus={false}
                    showIndicators={true}
                    infiniteLoop={true} 
                    centerMode={true}
                    centerSlidePercentage={33.33}
                    selectedItem={1}

                    renderArrowPrev={(clickHandler, hasPrev) => (
                        <button
                            onClick={clickHandler}
                            className="absolute left-0 z-10 top-1/2 -translate-y-1/2 bg-[#FAF8F5] text-[#1E3A5F] p-2 rounded-full hover:bg-opacity-80 transition-all"
                        >
                            ←
                        </button>
                    )}

                    renderArrowNext={(clickHandler, hasNext) => (
                        <button
                            onClick={clickHandler}
                            className="absolute right-0 z-10 top-1/2 -translate-y-1/2 bg-[#FAF8F5] text-[#1E3A5F] p-2 rounded-full hover:bg-opacity-80 transition-all"
                        >
                            →
                        </button>
                    )}
                    className="custom-carousel"
                >
                    {projects.map((project, index) => (
                        <div key={index} className="px-4 ">
                            <div className="bg-[#FAF8F5] rounded-lg shadow-xl p-4 m-2 h-[400px] flex flex-col">
                                <img 
                                    src={project.imageUrl} 
                                    alt={project.title}
                                    className="w-full h-48 object-cover rounded-lg mb-4" 
                                />
                                <h3 className="text-xl font-bold text-[#1E3A5F] mb-2">{project.title}</h3>
                                <p className="text-[#2B2B2B]">{project.description}</p>
                                <button className="mt-auto bg-[#1E3A5F] text-[#FAF8F5] py-2 px-4 rounded hover:bg-opacity-90 transition-all">
                                    Voir plus
                                </button>
                            </div>
                        </div>
                    ))}
                </Carousel>
            </div>
            
        </section>
    );
};

export default Project;
