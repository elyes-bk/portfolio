'use client'
import React, { useEffect, useState } from "react";
import { motion, useAnimation } from "framer-motion";

const Stack = () => {

    const stacks = [
        {
            title: "React",
            imageUrl: "/assets/react.png"
        },
        {
            title: "React Native",
            imageUrl: "/assets/react_native.png"
        },
        {
            title: "C++",
            imageUrl: "/assets/c++.png"
        },
        {
            title: "Python",
            imageUrl: "/assets/python.png"
        },
        {
            title: "NodeJS",
            imageUrl: "/assets/NodeJS.png"
        },
        {
            title: "NextJS",
            imageUrl: "/assets/NextJS.png"
        },
        {
            title: "JavaScript",
            imageUrl: "/assets/JS.png"
        },
        {
            title: "Tailwind CSS",
            imageUrl: "/assets/Tailwind.png"
        },
        {
            title: "HTML",
            imageUrl: "/assets/HTML.png"   
        },
        {
            title: "CSS",
            imageUrl: "/assets/CSS.png"
        },
        {
            title: "WordPress",
            imageUrl: "/assets/wordpress.png"
        },
        {
            title: "Figma",
            imageUrl: "/assets/Figma.png"
        },
    ]

    const [width, setWidth] = useState(0);
    useEffect(() => {
        setWidth(window.innerWidth);
    }, []);

    return (
        <section className="py-16 bg-[#FAF8F5] overflow-hidden">
            <h2 className="text-3xl font-bold text-center text-[#1E3A5F] mb-10">Technologies</h2>
            
            <div className="relative w-full">
                {/* Premier défilement */}
                <motion.div 
                    className="flex gap-8"
                    animate={{
                        x: [0, -width]
                    }}
                    transition={{
                        duration: 20,
                        repeat: Infinity,
                        ease: "linear",
                        repeatType: "loop"
                    }}
                >
                    {[...stacks, ...stacks].map((stack, index) => (
                        <div key={index} className="flex flex-col items-center min-w-[100px]">
                            <img 
                                src={stack.imageUrl} 
                                alt={stack.title} 
                                className="w-16 h-16 object-contain"
                            />
                            <p className="mt-2 text-sm text-[#1E3A5F]">{stack.title}</p>
                        </div>
                    ))}
                </motion.div>

               
            </div>
        </section>
    );
};

export default Stack;